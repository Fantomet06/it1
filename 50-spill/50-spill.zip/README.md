to run the code:
```bash
npm install
npm run dev
```