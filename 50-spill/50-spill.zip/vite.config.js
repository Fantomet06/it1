export default ({
  root: './src',
})